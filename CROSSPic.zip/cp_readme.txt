______________________

*      CROSSPic      *
______________________

1) Summary

	CROSSPic is a program that allows the user to solve and create nonograms.
	For more information about nonograms and how to solve them, I recommend starting out by visiting the Wikipedia page on nonograms.
	In this program, all nonograms are binary (black and white) and (to the fullest of my knowledge) solvable without trial and error.
	Upon solving a nonogram, the current date and time along with the best overall performance is saved and checkmarks are issued accordingly.
	The overall completion of all of the nonograms is presented as a percentage out of 100 on the puzzle selection menu.
	A score of 100 indicates that 3 checkmarks were attained for all puzzles in the program.

2) Controls

	Menus
		
		D/Enter:	make selection,
				change setting for selected option in options menu
		
		E/B:		return to previous screen
				(last selected puzzle will be maintained when exiting the puzzle selection menu)
		
		Up/Down:	change selection
		
		Left/Right:	cycle through puzzles for selected size in puzzle selection menu,
				change setting for selected option in options menu
		
				(all options will be saved upon exiting the options menu and restored upon starting up the program)
		
	Puzzle & Draw Mode
		
		Up/Down/Left/Right:	move cursor
					(cursor will wrap around board when exceeding its parameters)
		
	Puzzle Mode
		
		D:	attempt to fill in the current square
			(if the square is not in the puzzle then a large X will be drawn and a strike will be given)
			(three strikes results in a loss)
			(upon filling in all squares in a given row or column, the respective numbers in the guides along the right or bottom of the board will be grayed out)
		
		E:	mark/unmark the current square
			(mark a square if it can be deduced to not be in the puzzle)
			(marking a square prevents from attempting to fill in that square)
		
		P:	pause the game
		
	Draw Mode
		
		D:	fill in the current square
		
		E:	erase the current square
		
		C:	clear the entire board
		
		I:	invert the entire board
			(all filled in squares will be erased and all empty squares will be filled in)
		
		M:	mirror the entire board
			(reflects the board horizontally)
		
		F:	flip the entire board
			(reflects the board vertically)
		
		L:	load a previously saved .dat file
			(only the name chosen when saving needs to be specified when loading: i.e. the filename cp_10_pic.dat requires typing "pic" when prompted)
			(not case sensitive)
			(files only of the selected grid size can be loaded)
		
		S:	save the current drawing to a .dat file
			(a name must be provided)
			(duplicates are overwritten)
			(directory is .../puzzles/user/)
		
		B:	return to size selection menu
		
			(the numeric guides to the right and the bottom of the board will reflect all changes made)

3) Disclaimer

	This program was written using JavaSE-1.8 on a 64-bit Windows 8.1 machine.
	I cannot guarantee that everything drawn to the screen will appear how I intended it to on other platforms.
